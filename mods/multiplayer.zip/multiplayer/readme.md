A work in progress, experimental multiplayer mod, using [peerjs](https://peerjs.com/) for connectivity

Credits: 

+ Icon by [Geotatah](https://freeicons.io/recruitment-icon-set-2/human-world-relation-connect-network-icon-380023)
on [freeicons.io](https://freeicons.io)
